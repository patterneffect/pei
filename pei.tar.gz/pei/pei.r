args=commandArgs(TRUE)

ref<-NULL; dat<-NULL; chr<-NULL; level<-2

if(length(args)==3) {
  ref<-args[1]; dat<-args[2]; chr<-args[3]
} else if(length(args)==4) {
  ref<-args[1]; dat<-args[2]; chr<-args[3]; level<-as.numeric(args[4])
} else {
  print("ERROR: Number of arguments is not correct.")
  q(save="no");
}

if(suppressMessages(require(Biostrings))==FALSE) {
  print("ERROR: Biostring package was not installed.")
  q(save="no")
}
if(suppressMessages(require(class))==FALSE) {
  print("ERROR: class package was not installed.")
  q(save="no")
}
if(suppressMessages(require(gtools))==FALSE) {
  print("ERROR: gtools package was not installed.")
  q(save="no")
}

print(paste("PEI for chromosome ",chr," in problem ",level,sep=""))
cat("\n")
print("Reading reference ....")
flush.console()

genome<-readDNAStringSet(ref)
chrnames<-names(genome)
chrindex<-which(chrnames %in% chr)
if(length(chrindex)!=1) {
  print("ERROR: Chromosome is not on the chromosome list of reference.")
  print("It must be one of the followings:")
  print(chrnames)
  q(save="no")
}

print("Reading data ....")
flush.console()

coverage<-read.csv(dat,sep="\t",header=FALSE,stringsAsFactors=FALSE)
coverage<-coverage[coverage[,1]==chr & coverage[,2]>20 & coverage[,2]<(width(genome)[chrindex]-19),]
if(nrow(coverage)==0) {
  print("ERROR: There is no chromsome data.")
  q(save="no")
}

zrcvg<-coverage[coverage[,3]==0,]
lwcvg<-coverage[coverage[,3]>0 & coverage[,3]<=5,]
mdcvg<-coverage[coverage[,3]>5 & coverage[,3]<=10,]
hgcvg<-coverage[coverage[,3]>10,]

rm(coverage)

size<-floor(nrow(lwcvg)*0.15)
if(size>=500) size<-500 else print(paste("Warning: only ",size," positions were selected for 1 - 5 reads",sep=""))
if(nrow(lwcvg)>0) lwrnd<-sample(1:nrow(lwcvg),size,replace=FALSE)

size<-floor(nrow(mdcvg)*0.15)
if(size>=500) size<-500 else print(paste("Warning: only ",size," positions were selected for 6 - 10 reads",sep=""))
if(nrow(mdcvg)>0) mdrnd<-sample(1:nrow(mdcvg),size,replace=FALSE)

size<-floor(nrow(hgcvg)*0.15)
if(size>=500) size<-500 else print(paste("Warning: only ",size," positions were selected for more than 10 reads",sep=""))
if(nrow(hgcvg)>0) hgrnd<-sample(1:nrow(hgcvg),size,replace=FALSE)

total<-0
if(level==1) {
  total<-length(lwrnd)+length(mdrnd)+length(hgrnd);
  if(total<300) {
    print("ERROR: Number of selected positions is less than 300.");
    q(save="no");
  }
} else if(level==2) {
  total<-length(mdrnd)+length(hgrnd);
  if(total<100) {
    print("ERROR: Number of selected positions is less than 100.");
    q(save="no");
  }
} else if(level==3) {
   total<-length(hgrnd);
  if(total<20) {
    print("ERROR: Number of selected positions is less than 20.");
    q(save="no");
  }
} else {
  print("ERROR: Problem is incorrect.");
  q(save="no");
}

if(total==0) {
  print("ERROR: Number of selected positions is 0.");
  q(save="no");
}
zrrnd<-sample(1:nrow(zrcvg),total,replace=FALSE)

V4<-"C1"
zrrndcvg<-cbind(zrcvg[zrrnd,],V4)
V4<-"C2"
lwrndcvg<-cbind(lwcvg[lwrnd,],V4)
mdrndcvg<-cbind(mdcvg[mdrnd,],V4)
hgrndcvg<-cbind(hgcvg[hgrnd,],V4)

rm(zrcvg)
rm(lwcvg)
rm(mdcvg)
rm(hgcvg)

size<-ceiling(nrow(zrrndcvg)/2)
trainzr<-zrrndcvg[1:size,]
testzr<-zrrndcvg[-(1:size),]
size<-ceiling(nrow(lwrndcvg)/2)
trainlw<-lwrndcvg[1:size,]
testlw<-lwrndcvg[-(1:size),]
size<-ceiling(nrow(mdrndcvg)/2)
trainmd<-mdrndcvg[1:size,]
testmd<-mdrndcvg[-(1:size),]
size<-ceiling(nrow(hgrndcvg)/2)
trainhg<-hgrndcvg[1:size,]
testhg<-hgrndcvg[-(1:size),]

if(level==1) {
  trainrnd<-rbind(trainzr,trainlw,trainmd,trainhg)
  testrnd<-rbind(testzr,testlw,testmd,testhg)
} else if(level==2) {
  trainrnd<-rbind(trainzr,trainmd,trainhg)
  testrnd<-rbind(testzr,testmd,testhg)
} else if(level==3) {
  trainrnd<-rbind(trainzr,trainhg)
  testrnd<-rbind(testzr,testhg)
}
trainrnd[,4]<-as.character(trainrnd[,4])
testrnd[,4]<-as.character(testrnd[,4])

train<-data.frame(NULL,stringsAsFactors=FALSE)
for(i in 1:nrow(trainrnd)) {
  pos<-trainrnd[i,2]
  seqchr<-genome[[chrindex]]
  seq<-DNAStringSet(seqchr,start=(pos-20),end=(pos+20))
  train<-rbind(train,cbind(t(strsplit(toString(seq),split="")[[1]]),trainrnd[i,4]))
}

test<-data.frame(NULL,stringsAsFactors=FALSE)
for(i in 1:nrow(testrnd)) {
  pos<-testrnd[i,2]
  seqchr<-genome[[chrindex]]
  seq<-DNAStringSet(seqchr,start=(pos-20),end=(pos+20))
  test<-rbind(test,cbind(t(strsplit(toString(seq),split="")[[1]]),testrnd[i,4]))
}

for(i in 1:41) {
  names(train)[i]<-paste("F",i,sep="")
  names(test)[i]<-paste("F",i,sep="")
}
names(train)[42]<-"Class"
names(test)[42]<-"Class"

nt1<-c('A','C','G','T')
nt2<-permutations(n=4,r=2,v=nt1,repeats.allowed=T)
nt3<-permutations(n=4,r=3,v=nt1,repeats.allowed=T)
nt4<-permutations(n=4,r=4,v=nt1,repeats.allowed=T)

cat("\n")
print("It may take some time.")
print("Calculating distribution (1/2) ....")
flush.console()

traindist<-data.frame(NULL,stringsAsFactors=FALSE)
for(i in 1:nrow(train)) {
  if(i%%100==0) {
    print(paste("Processing ",i,"/",nrow(train)," ....",sep=""))
    flush.console()
  }

  traincount1<-c(rep(0,each=length(nt1)))
  traincount2<-c(rep(0,each=nrow(nt2)))
  traincount3<-c(rep(0,each=nrow(nt3)))
  traincount4<-c(rep(0,each=nrow(nt4)))

  for(j in 1:41) {
    for(k in 1:length(nt1)) {
      if(train[i,j]==nt1[k]) traincount1[k]<-traincount1[k]+1
    }
    if(j<41) {
      for(k in 1:nrow(nt2)) {
	if(train[i,j]==nt2[k,1] && train[i,j+1]==nt2[k,2]) traincount2[k]<-traincount2[k]+1
      }
    }
    if(j<40) {
      for(k in 1:nrow(nt3)) {
	if(train[i,j]==nt3[k,1] && train[i,j+1]==nt3[k,2] && train[i,j+2]==nt3[k,3]) traincount3[k]<-traincount3[k]+1
      }
    }
    if(j<39) {
      for(k in 1:nrow(nt4)) {
	if(train[i,j]==nt4[k,1] && train[i,j+1]==nt4[k,2] && train[i,j+2]==nt4[k,3] && train[i,j+3]==nt4[k,4]) traincount4[k]<-traincount4[k]+1
      }
    }
  }

  trainsum1<-sum(traincount1)
  trainsum2<-sum(traincount2)
  trainsum3<-sum(traincount3)
  trainsum4<-sum(traincount4)

  trainratio1<-c(rep(0,each=length(nt1)))
  trainratio2<-c(rep(0,each=nrow(nt2)))
  trainratio3<-c(rep(0,each=nrow(nt3)))
  trainratio4<-c(rep(0,each=nrow(nt4)))

  if(trainsum1==0) {
    for(k in 1:length(nt1)) trainratio1[k]<-0
  } else {
    for(k in 1:length(nt1)) trainratio1[k]<-traincount1[k]/trainsum1
  }

  if(trainsum2==0) {
    for(k in 1:nrow(nt2)) trainratio2[k]<-0
  } else {
    for(k in 1:nrow(nt2)) trainratio2[k]<-traincount2[k]/trainsum2
  }

  if(trainsum3==0) {
    for(k in 1:nrow(nt3)) trainratio3[k]<-0
  } else {
    for(k in 1:nrow(nt3)) trainratio3[k]<-traincount3[k]/trainsum3
  }

  if(trainsum4==0) {
    for(k in 1:nrow(nt4)) trainratio4[k]<-0
  } else {
    for(k in 1:nrow(nt4)) trainratio4[k]<-traincount4[k]/trainsum4
  }

  traindist<-rbind(traindist,c(trainratio1,trainratio2,trainratio3,trainratio4,0))
}

traindist[,(length(nt1)+nrow(nt2)+nrow(nt3)+nrow(nt4)+1)]<-train[,ncol(train)]
colnames(traindist)<-c(nt1,paste(nt2[,1],nt2[,2],sep=""),paste(nt3[,1],nt3[,2],nt3[,3],sep=""),paste(nt4[,1],nt4[,2],nt4[,3],nt4[,4],sep=""),"Class")

rm(train)

print("Calculating distribution (2/2) ....")
flush.console()

testdist<-data.frame(NULL,stringsAsFactors=FALSE)
for(i in 1:nrow(test)) {
  if(i%%100==0) {
    print(paste("Processing ",i,"/",nrow(test)," ....",sep=""))
      flush.console()
  }

  testcount1<-c(rep(0,each=length(nt1)))
  testcount2<-c(rep(0,each=nrow(nt2)))
  testcount3<-c(rep(0,each=nrow(nt3)))
  testcount4<-c(rep(0,each=nrow(nt4)))

  for(j in 1:41) {
    for(k in 1:length(nt1)) {
      if(test[i,j]==nt1[k]) testcount1[k]<-testcount1[k]+1
    }
    if(j<41) {
      for(k in 1:nrow(nt2)) {
	if(test[i,j]==nt2[k,1] && test[i,j+1]==nt2[k,2]) testcount2[k]<-testcount2[k]+1
      }
    }
    if(j<40) {
      for(k in 1:nrow(nt3)) {
	if(test[i,j]==nt3[k,1] && test[i,j+1]==nt3[k,2] && test[i,j+2]==nt3[k,3]) testcount3[k]<-testcount3[k]+1
      }
    }
    if(j<39) {
      for(k in 1:nrow(nt4)) {
	if(test[i,j]==nt4[k,1] && test[i,j+1]==nt4[k,2] && test[i,j+2]==nt4[k,3] && test[i,j+3]==nt4[k,4]) testcount4[k]<-testcount4[k]+1
      }
    }
  }

  testsum1<-sum(testcount1)
  testsum2<-sum(testcount2)
  testsum3<-sum(testcount3)
  testsum4<-sum(testcount4)

  testratio1<-c(rep(0,each=length(nt1)))
  testratio2<-c(rep(0,each=nrow(nt2)))
  testratio3<-c(rep(0,each=nrow(nt3)))
  testratio4<-c(rep(0,each=nrow(nt4)))

  if(testsum1==0) {
    for(k in 1:length(nt1)) testratio1[k]<-0
  } else {
    for(k in 1:length(nt1)) testratio1[k]<-testcount1[k]/testsum1
  }

  if(testsum2==0) {
    for(k in 1:nrow(nt2)) testratio2[k]<-0
  } else {
    for(k in 1:nrow(nt2)) testratio2[k]<-testcount2[k]/testsum2
  }

  if(testsum3==0) {
    for(k in 1:nrow(nt3)) testratio3[k]<-0
  } else {
    for(k in 1:nrow(nt3)) testratio3[k]<-testcount3[k]/testsum3
  }

  if(testsum4==0) {
    for(k in 1:nrow(nt4)) testratio4[k]<-0
  } else {
    for(k in 1:nrow(nt4)) testratio4[k]<-testcount4[k]/testsum4
  }

  testdist<-rbind(testdist,c(testratio1,testratio2,testratio3,testratio4,0))
}

testdist[,(length(nt1)+nrow(nt2)+nrow(nt3)+nrow(nt4)+1)]<-test[,ncol(test)]
colnames(testdist)<-c(nt1,paste(nt2[,1],nt2[,2],sep=""),paste(nt3[,1],nt3[,2],nt3[,3],sep=""),paste(nt4[,1],nt4[,2],nt4[,3],nt4[,4],sep=""),"Class")

rm(test)

cat("\n")
print("Writing train and test files ....")
flush.console()

write.table(traindist,file="traindist.txt",sep="\t",quote=FALSE,row.names=FALSE,col.name=TRUE)
write.table(testdist,file="testdist.txt",sep="\t",quote=FALSE,row.names=FALSE,col.name=TRUE)

cat("\n")
print("Cacluating PEI ....")
flush.console()

class<-factor(traindist[,ncol(traindist)])
predicted<-knn(traindist[,-ncol(traindist)],testdist[,-ncol(testdist)],cl=class,k=3)

confusion<-table(testdist$Class,predicted)
acc<-(confusion[1,1]+confusion[2,2])/(confusion[1,1]+confusion[1,2]+confusion[2,1]+confusion[2,2])
pei<-(acc-0.5)/0.5

cat("\n")
print(paste("Accuracy: ",(acc*100),"%",sep=""))
print(paste("PEI: ",pei,sep=""))

q(save="no")

