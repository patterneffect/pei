Usage
pei.sh reference input chromosome [problem]

Mendatory arguments
- reference: reference genome in fasta format
- input: tab-delimited text data including chromosome, read start position (1-based coordinate), and read frequency, without column header. For example,
  chr1	10000	0
  chr1	10001	0
  chr1	10002	2
  chr1	10003	4
  chr1	10004	0
- chromosome: chromosome name that must be one of the chromosome names in the reference genome and input data

Optional argument
- problem (default 2)
  1: 0 vs. 1 or more
  2: 0 vs. 6 or more
  3: 0 vs. 11 or more

Outputs
- Train and test files in directory
- Classification accuracy on screen
- PEI on screen

Example command
- pei.sh examplegenome.fa example.txt chr1 2
- This example command calculates PEI for the chromosome chr1 of the reference (examplegenome.fa) and input (example.txt) data in the problem 2.

Requirements
- Linux system
- R software
- R package of "Biostrings"
- R package of "class"
- R package of "gtools"

Note
- If the file of "pei.sh" is not executable, type "chmod +x pei.sh" and press enter.

