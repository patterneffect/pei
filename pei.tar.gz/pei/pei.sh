#!/bin/bash

Rscript --vanilla pei.r $1 $2 $3 $4

